/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./pages/**/*.{js,ts,jsx,tsx}",
    "./components/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        'primary': '#616b77',
        'base':'#f2f2f2',
        'secondary': '#8bb8a2',
        'blue':"#4c4e8d",
        

      },
      fontFamily:{
        heading:"'Belleza', sans-serif",
        subText:"'Source Sans Pro', sans-serif",
        main:"'Work Sans', sans-serif"

      }
    },
  },
  plugins: [],
}
