import React from 'react'
import Login from '../components/Login'

function index() {
  return (
   <>
   <Login />

   </>
  )
}

export default index