import React from 'react'
import MainContainer from '../../components/MainContainer'
import EditClient from '../../components/Onboard/EditClient'
function index() {
  return (
   <>
   <MainContainer pageContent={<EditClient />} />

   </>
  )
}

export default index