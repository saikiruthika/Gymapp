import React from 'react'
import Signup from "../../components/Signup"
export default function index() {
  return (
    <Signup />
  )
}
