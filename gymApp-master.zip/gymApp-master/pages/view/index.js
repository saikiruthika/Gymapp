import React from 'react'
import MainContainer from '../../components/MainContainer'
import View from '../../components/Onboard/ViewClients'
function index() {
  return (
   <>
   <MainContainer pageContent={<View />} />

   </>
  )
}

export default index