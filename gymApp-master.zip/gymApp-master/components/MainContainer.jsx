import React from 'react'
import Sidebar from './SideNav'
import Container from './Container'
export default function MainContainer({pageContent}) {
  return (
 <section className="bg-primary w-full h-screen">
    <div className="grid grid-cols-7">
    {/* Attaching Sidebar */}     
<Sidebar/>

<Container Content={pageContent}/>
  
    </div>
<div>

</div>
 </section>

  )
}
