import React from 'react'
import Link from "next/link"
export default function SideNav() {
    const style={  width: "90px",
        height: "90px",
        backgroundImage: "radial-gradient(rgb(69, 82, 102) 10%, transparent 11%), radial-gradient(rgb(69, 82, 102) 10%, transparent 11%)",
        backgroundSize: "15px 15px",
        backgroundPosition: "0 0, 30px 30px",
        backgroundRepeat: "repeat"}
  return (
    <div className="col-span-1 px-10 py-8 text-white font-main  flex flex-col items-center">
        <div className="text-3xl">logo</div>
        {/* profile pic */}
        <div className="py-11 relative">
        <div className='absolute z-0 translate-x-4 -translate-y-6' style={style}></div>
        <img src="https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2" alt="profile-pic"
        className="rounded-full w-20 h-20 object-cover z-2 relative"
        />
        <h3 className="font-semibold capitalize">john smith</h3>
        </div>
        <div>
            <ul className="tracking-wide hover:cursor-pointer ">
                
                <li className="my-5 text-slate-300 hover:text-white">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5 mx-2 inline-block">
  <path fillRule="evenodd" d="M6.912 3a3 3 0 00-2.868 2.118l-2.411 7.838a3 3 0 00-.133.882V18a3 3 0 003 3h15a3 3 0 003-3v-4.162c0-.299-.045-.596-.133-.882l-2.412-7.838A3 3 0 0017.088 3H6.912zm13.823 9.75l-2.213-7.191A1.5 1.5 0 0017.088 4.5H6.912a1.5 1.5 0 00-1.434 1.059L3.265 12.75H6.11a3 3 0 012.684 1.658l.256.513a1.5 1.5 0 001.342.829h3.218a1.5 1.5 0 001.342-.83l.256-.512a3 3 0 012.684-1.658h2.844z" clipRule="evenodd" />
</svg>

<Link href="/dashboard">Dashboard</Link>
                </li>
                <li className="my-5 text-slate-300 hover:text-white">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" class="w-5 h-5 inline-block mx-2">
  <path fill-rule="evenodd" d="M5.25 2.25a3 3 0 00-3 3v4.318a3 3 0 00.879 2.121l9.58 9.581c.92.92 2.39 1.186 3.548.428a18.849 18.849 0 005.441-5.44c.758-1.16.492-2.629-.428-3.548l-9.58-9.581a3 3 0 00-2.122-.879H5.25zM6.375 7.5a1.125 1.125 0 100-2.25 1.125 1.125 0 000 2.25z" clip-rule="evenodd" />
</svg>


 <Link href="/view">View Clients</Link>
                </li>
               
                
               
            </ul>
            <div className="absolute bottom-4 text-sm">
            <Link href="/">Logout</Link>
            </div>
        </div>
</div>
  )
}
