import React from 'react'

export default function Container({Content}) {
  return (
    <div className="col-span-6 rounded-tl-3xl shadow-xl px-8 pt-10 bg-base w-full h-screen overflow-auto">
   
     {Content}
    </div>
  )
}
