import React, { useEffect, useRef, useState } from 'react'
import Style from "./Registration.module.css"
import { useForm } from "react-hook-form";
import axios from "axios"
import { useRouter } from 'next/router'
import Swal from "sweetalert2"
const instance = axios.create({
  withCredentials: true
});
export default function RegisterForm() {
    
    const [data,setData] = useState([]);
    const router = useRouter()
    const { id } = router.query
    const { register, handleSubmit, formState: { errors } } = useForm();
    const onSubmit =(e)=>{
        e.preventDefault();
        
         let data = {
            firstName:e.target.firstName.value,
            lastName:e.target.lastName.value,
            email:e.target.email.value,
            address:e.target.address.value,
            gender:e.target.gender.value,
            phone:e.target.phone.value,
            dob:e.target.dob.value,
            height:e.target.height.value,
            weight:e.target.weight.value,

        }
         console.log(data)
        instance.put(`${process.env.BASE_URL}/client/${id}`,data).then(res=>{
            getClientDetails(id)
        Swal.fire({icon:"success",text:res.data.msg})
        
      }).catch(err=>{
        console.log(err)
        Swal.fire({icon:"error",text:"Problem creating record"})
      })
  }
  useEffect(()=>{
    getClientDetails(id)
  },[id])

  const getClientDetails = (id)=>{
    console.log(id)
    instance.get(`${process.env.BASE_URL}/client/${id}`).then(res=>{
        setData(res.data)
        console.log(res.data)
    }).catch(err=>{
        console.log(err)
    })
  }

  return (
    <div>
        <h2 className="font-heading font-semibold text-slate-700 text-lg mb-8">Edit client details </h2>
        {/* <div className={Style.progressbar}>
  <div className={Style.progressHalf1 } id="progress1" />
  <div id='prog1' className={Style.progressStep +" "+ Style.progressStepActive} data-title="Basic Info" />
  <div  className={Style.progressHalf2} id="progress2" />
  <div id='prog2' className={Style.progressStep} data-title="Medical condition" />
  <div id='prog3' className={Style.progressStep} data-title="Plan" />
  
</div> */}

<form id="dataForm" className="bg-white  rounded-2xl shadow-lg font-subText" onSubmit={onSubmit}>


<div className={`border-b-2 px-9 pt-4 pb-2 before:h-2 ${Style.underline}`}>
        <h3 className="font-subText inline-block text-slate-700 text-lg font-semibold">Basic Info</h3>
        <p className="inline-block text-gray-400 mx-2 font-light ">(approx 5 min)</p>
    </div>
    <div  className={`px-6 py-6 ${Style.formStep} ${Style.formStepActive}`}>

    
    <div className="grid md:grid-cols-2 md:gap-6">
    <div className="relative z-0 mb-6 w-full group">
      <input defaultValue={data.firstName} type="text" {...register("firstName",{ required: true })} name="firstName" id="" className="block py-2.5 px-0 w-full text-sm text-gray-900 bg-transparent border-0 border-b-2 border-gray-300 appearance-none dark:text-white dark:border-gray-600 dark:focus:border-blue-500 focus:outline-none focus:ring-0 focus:border-blue-600 peer" placeholder=" " required  />
      <label htmlFor="floating_phone" className="peer-focus:font-medium absolute text-sm text-gray-500 dark:text-gray-400 duration-300 transform -translate-y-6 scale-75 top-3 -z-10 origin-[0] peer-focus:left-0 peer-focus:text-blue-600 peer-focus:dark:text-blue-500 peer-placeholder-shown:scale-100 peer-placeholder-shown:translate-y-0 peer-focus:scale-75 peer-focus:-translate-y-6">First Name</label>
    </div>
    <div className="relative z-0 mb-6 w-full group">
      <input defaultValue={data.lastName} type="text" {...register("lastName",{ required: true })} name="lastName" id="" className="block py-2.5 px-0 w-full text-sm text-gray-900 bg-transparent border-0 border-b-2 border-gray-300 appearance-none dark:text-white dark:border-gray-600 dark:focus:border-blue-500 focus:outline-none focus:ring-0 focus:border-blue-600 peer" placeholder=" " required  />
      <label htmlFor="floating_company" className="peer-focus:font-medium absolute text-sm text-gray-500 dark:text-gray-400 duration-300 transform -translate-y-6 scale-75 top-3 -z-10 origin-[0] peer-focus:left-0 peer-focus:text-blue-600 peer-focus:dark:text-blue-500 peer-placeholder-shown:scale-100 peer-placeholder-shown:translate-y-0 peer-focus:scale-75 peer-focus:-translate-y-6">Last Name</label>
    </div>
  </div>
  {/* <div className="relative z-0 mb-6 w-full group">
    <input type="text" name="floating_password" id="floating_password" className="block py-2.5 px-0 w-full text-sm text-gray-900 bg-transparent border-0 border-b-2 border-gray-300 appearance-none dark:text-white dark:border-gray-600 dark:focus:border-blue-500 focus:outline-none focus:ring-0 focus:border-blue-600 peer" placeholder=" " required />
    <label htmlFor="floating_password" className="peer-focus:font-medium absolute text-sm text-gray-500 dark:text-gray-400 duration-300 transform -translate-y-6 scale-75 top-3 -z-10 origin-[0] peer-focus:left-0 peer-focus:text-blue-600 peer-focus:dark:text-blue-500 peer-placeholder-shown:scale-100 peer-placeholder-shown:translate-y-0 peer-focus:scale-75 peer-focus:-translate-y-6">Last Name</label>
  </div> */}
  <div className="relative z-0 mb-6 w-full group">
    <input defaultValue={data.email} type="email" {...register("email",{ required: true })} name="email" id="floating_repeat_password" className="block py-2.5 px-0 w-full text-sm text-gray-900 bg-transparent border-0 border-b-2 border-gray-300 appearance-none dark:text-white dark:border-gray-600 dark:focus:border-blue-500 focus:outline-none focus:ring-0 focus:border-blue-600 peer" placeholder=" " required />
    <label htmlFor="floating_repeat_password" className="peer-focus:font-medium absolute text-sm text-gray-500 dark:text-gray-400 duration-300 transform -translate-y-6 scale-75 top-3 -z-10 origin-[0] peer-focus:left-0 peer-focus:text-blue-600 peer-focus:dark:text-blue-500 peer-placeholder-shown:scale-100 peer-placeholder-shown:translate-y-0 peer-focus:scale-75 peer-focus:-translate-y-6">Email</label>
  </div>
  <div className="grid md:grid-cols-2 md:gap-6">
    <div className="relative z-0 mb-6 w-full group">
      <input defaultValue={data.phone} type="tel" pattern="[0-9]{10}" {...register("phone",{ required: true })} name="phone" id="floating_first_name" className="block py-2.5 px-0 w-full text-sm text-gray-900 bg-transparent border-0 border-b-2 border-gray-300 appearance-none dark:text-white dark:border-gray-600 dark:focus:border-blue-500 focus:outline-none focus:ring-0 focus:border-blue-600 peer" placeholder=" " required />
      <label htmlFor="floating_first_name" className="peer-focus:font-medium absolute text-sm text-gray-500 dark:text-gray-400 duration-300 transform -translate-y-6 scale-75 top-3 -z-10 origin-[0] peer-focus:left-0 peer-focus:text-blue-600 peer-focus:dark:text-blue-500 peer-placeholder-shown:scale-100 peer-placeholder-shown:translate-y-0 peer-focus:scale-75 peer-focus:-translate-y-6">Phone number (123-456-7890) </label>
    </div>
    <div className="relative z-0 mb-6 w-full group">
      <input defaultValue={data.dob} type="date" {...register("dob",{ required: true })} name="dob" id="floating_last_name" className="block py-2.5 px-0 w-full text-sm text-gray-900 bg-transparent border-0 border-b-2 border-gray-300 appearance-none dark:text-white dark:border-gray-600 dark:focus:border-blue-500 focus:outline-none focus:ring-0 focus:border-blue-600 peer" placeholder=" " required />
      <label htmlFor="floating_last_name" className="peer-focus:font-medium absolute text-sm text-gray-500 dark:text-gray-400 duration-300 transform -translate-y-6 scale-75 top-3 -z-10 origin-[0] peer-focus:left-0 peer-focus:text-blue-600 peer-focus:dark:text-blue-500 peer-placeholder-shown:scale-100 peer-placeholder-shown:translate-y-0 peer-focus:scale-75 peer-focus:-translate-y-6">DoB</label>
    </div>
  </div>
  <div className="grid md:grid-cols-2 md:gap-6">
    <div className="relative z-0 mb-6 w-full group">
      <input defaultValue={data.gender} type="tet" {...register("gender",{ required: true })} name="gender" id="floating_phone" className="block py-2.5 px-0 w-full text-sm text-gray-900 bg-transparent border-0 border-b-2 border-gray-300 appearance-none dark:text-white dark:border-gray-600 dark:focus:border-blue-500 focus:outline-none focus:ring-0 focus:border-blue-600 peer" placeholder=" " required />
      <label htmlFor="floating_phone" className="peer-focus:font-medium absolute text-sm text-gray-500 dark:text-gray-400 duration-300 transform -translate-y-6 scale-75 top-3 -z-10 origin-[0] peer-focus:left-0 peer-focus:text-blue-600 peer-focus:dark:text-blue-500 peer-placeholder-shown:scale-100 peer-placeholder-shown:translate-y-0 peer-focus:scale-75 peer-focus:-translate-y-6">Gender</label>
    </div>
    <div className="relative z-0 mb-6 w-full group">
      <input type="text" defaultValue={data.address} {...register("address",{ required: true })} name="address" id="floating_company" className="block py-2.5 px-0 w-full text-sm text-gray-900 bg-transparent border-0 border-b-2 border-gray-300 appearance-none dark:text-white dark:border-gray-600 dark:focus:border-blue-500 focus:outline-none focus:ring-0 focus:border-blue-600 peer" placeholder=" " required />
      <label htmlFor="floating_company" className="peer-focus:font-medium absolute text-sm text-gray-500 dark:text-gray-400 duration-300 transform -translate-y-6 scale-75 top-3 -z-10 origin-[0] peer-focus:left-0 peer-focus:text-blue-600 peer-focus:dark:text-blue-500 peer-placeholder-shown:scale-100 peer-placeholder-shown:translate-y-0 peer-focus:scale-75 peer-focus:-translate-y-6">Address</label>
    </div>
  </div>
  <div className="grid md:grid-cols-2 md:gap-6">
    <div className="relative z-0 mb-6 w-full group">
      <input type="text" defaultValue={data.height} {...register("height",{ required: true })} name="height" id="floating_phone" className="block py-2.5 px-0 w-full text-sm text-gray-900 bg-transparent border-0 border-b-2 border-gray-300 appearance-none dark:text-white dark:border-gray-600 dark:focus:border-blue-500 focus:outline-none focus:ring-0 focus:border-blue-600 peer" placeholder=" " required />
      <label htmlFor="floating_phone" className="peer-focus:font-medium absolute text-sm text-gray-500 dark:text-gray-400 duration-300 transform -translate-y-6 scale-75 top-3 -z-10 origin-[0] peer-focus:left-0 peer-focus:text-blue-600 peer-focus:dark:text-blue-500 peer-placeholder-shown:scale-100 peer-placeholder-shown:translate-y-0 peer-focus:scale-75 peer-focus:-translate-y-6">Height (in cm)</label>
    </div>
    <div className="relative z-0 mb-6 w-full group">
      <input type="text" defaultValue={data.weight} {...register("weight",{ required: true })} name="weight" id="floating_company" className="block py-2.5 px-0 w-full text-sm text-gray-900 bg-transparent border-0 border-b-2 border-gray-300 appearance-none dark:text-white dark:border-gray-600 dark:focus:border-blue-500 focus:outline-none focus:ring-0 focus:border-blue-600 peer" placeholder=" " required />
      <label htmlFor="floating_company" className="peer-focus:font-medium absolute text-sm text-gray-500 dark:text-gray-400 duration-300 transform -translate-y-6 scale-75 top-3 -z-10 origin-[0] peer-focus:left-0 peer-focus:text-blue-600 peer-focus:dark:text-blue-500 peer-placeholder-shown:scale-100 peer-placeholder-shown:translate-y-0 peer-focus:scale-75 peer-focus:-translate-y-6">Weigh (in Kg)</label>
    </div>
  </div>
  <div>
    <button type="submit" className="border-blue border-2 px-2 py-1 rounded-2xl text-blue font-subText hover:bg-blue hover:text-white hover:-translate-y-0.5 transition-all ease-linear active:translate-y-0">submit</button>
  </div>
</div>
 


</form>
</div>

  )
}
