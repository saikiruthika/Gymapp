import React, { useEffect, useState } from 'react'
import axios from "axios"
import Link from "next/link"
import ReactPaginate from "react-paginate"
import Swal from "sweetalert2"
const instance = axios.create({
  withCredentials: true
});
export default function ViewClients() {
    const [offset,setOffset]= useState(0)
    const [data,setData]= useState([])
    const [perPage,setPerPage]=useState(10)
    const [splice ,setSplice]=useState([])
    const [currentPage,setCurrentPage]=useState(0)
    const [pageCount,setPageCount] = useState(0)
    useEffect(()=>{
        getClients()
    },[])
    const getClients =()=>{
        instance.get(`${process.env.BASE_URL}/client`).then(res=>{
            const data = res.data;
            setPageCount(Math.ceil(data.length / perPage))
            setData(data)
            slice(data)
        }).catch(err=>{
            console.log(err)
        })
    }
    const slice = (data)=>{
        const slice = data.slice(offset, offset + perPage)
        setSplice(slice)
        console.log(slice)
    }

  const  handlePageClick = (e) => {
    console.log(e)
        const selectedPage = e.selected;
        const offset = selectedPage * perPage;
        setCurrentPage(selectedPage)
        setOffset(offset)
       slice(data)

    };
    const handleEdit = (id)=>{
        console.log(id)
    }
    const handleDelete= (id)=>{
        Swal.fire({
            title: 'Are you sure?',
            text: "You won't be able to revert this!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, delete it!'
          }).then((result) => {
            instance.delete(`${process.env.BASE_URL}/client/${id}`).then(res=>{
                if (result.isConfirmed) {
                    Swal.fire(
                      'Deleted!',
                      'Your file has been deleted.',
                      'success'
                    )
                  }
                  getClients()
            })
            
          })

    }
    const handleGenBMI= (id)=>{
        instance.get(`${process.env.BASE_URL}/client/generateBMI/${id}`).then(res=>{
            console.log(res.data)
            Swal.fire({icon:"info",text:`Your calculated BMI is ${res.data.bmi} and the condition is ${res.data.range}`})
        }).catch(err=>{
            console.log(err)
        })
    }
  return (
<>
<h3 className="text-2xl font-main mb-3">Client Details</h3>
<div className="overflow-x-auto relative shadow-md sm:rounded-lg">
  <table className="w-full text-sm text-left text-gray-500 dark:text-gray-400">
    <thead className="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
      <tr>
        <th scope="col" className="py-3 px-6">
         Name
        </th>
        <th scope="col" className="py-3 px-6">
          Email
        </th>
        <th scope="col" className="py-3 px-6">
          DoB
        </th>
        <th scope="col" className="py-3 px-6">
          Gender
        </th>
        <th scope="col" className="py-3 px-6">
          Action
        </th>
        <th scope="col" className="py-3 px-6">
          Action
        </th>
        <th scope="col" className="py-3 px-6">
          Action
        </th>
      </tr>
    </thead>
    <tbody>
    
      {splice.map((val,key)=>{
        return(
          <tr key={val._id} className="bg-white border-b dark:bg-gray-900 dark:border-gray-700">
          <th scope="row" className="py-4 px-6 font-medium text-gray-900 whitespace-nowrap dark:text-white">
            {val.firstName} {val.lastName}
          </th>
          <td className="py-4 px-6">
          {val.email}
          </td>
          <td className="py-4 px-6">
           {val.dob}
          </td>
          <td className="py-4 px-6">
          {val.gender}
          </td>
          <td className="py-4 px-6">
            <a  className="font-medium text-blue dark:text-blue-500 hover:underline"><Link href={`/edit/${val._id}`}>Edit</Link></a>
          </td>
          <td className="py-4 px-6">
            <a onClick={()=>handleDelete(val._id)} className="font-medium text-red-700 dark:text-blue-500 hover:underline">Delete</a>
          </td>
          <td className="py-4 px-6">
            <a onClick={()=>handleGenBMI(val._id)} className="font-medium text-yellow-700 dark:text-blue-500 hover:underline">Generate BMI</a>
          </td>
        </tr>
        )
      })}
   
    </tbody>
  </table>
</div>



<div className="mt-4 flex justify-center mb-4">

   
<ReactPaginate
                    previousLabel={"prev"}
                    nextLabel={"next"}
                    nextClassName="block px-3 py-2 leading-tight text-gray-500 bg-white border border-gray-300 rounded-r-lg hover:bg-gray-100 hover:text-gray-700 dark:bg-gray-800 dark:border-gray-700 dark:text-gray-400 dark:hover:bg-gray-700 dark:hover:text-white"
                    previousLinkClassName="block px-3 py-2 ml-0 leading-tight text-gray-500 bg-white border border-gray-300 rounded-l-lg hover:bg-gray-100 hover:text-gray-700 dark:bg-gray-800 dark:border-gray-700 dark:text-gray-400 dark:hover:bg-gray-700 dark:hover:text-white"
                    breakLabel={"..."}
                    breakLinkClassName="px-3 py-2 leading-tight text-gray-500 bg-white border border-gray-300 hover:bg-gray-100 hover:text-gray-700 dark:bg-gray-800 dark:border-gray-700 dark:text-gray-400 dark:hover:bg-gray-700 dark:hover:text-white"
                    pageLinkClassName="px-3 py-2 leading-tight text-gray-500 bg-white border border-gray-300 hover:bg-gray-100 hover:text-gray-700 dark:bg-gray-800 dark:border-gray-700 dark:text-gray-400 dark:hover:bg-gray-700 dark:hover:text-white"
                    pageCount={pageCount}
                    marginPagesDisplayed={2}
                    pageRangeDisplayed={5}
                    onPageChange={handlePageClick}
                    containerClassName={"inline-flex items-center -space-x-px"}
                    breakClassName={"pages pagination"}
                    activeClassName={"bg-gray-400"}/>

</div>
</>
  )
}
