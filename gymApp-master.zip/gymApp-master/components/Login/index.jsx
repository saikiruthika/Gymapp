import React from 'react'
import Link from "next/link"
import axios from "axios"
import { useForm } from "react-hook-form";
import { useRouter } from 'next/router'
import {IoLogoXing} from "react-icons/io5"
const instance = axios.create({
    withCredentials: true
});
import Swal from "sweetalert2"
export default function Login() {
    const { register, handleSubmit, formState: { errors } } = useForm();
    const router = useRouter()
    const onSubmit =(data)=>{
        console.log(data)
        instance.post(`${process.env.BASE_URL}/customer/login`,data).then(res=>{
            router.push("/dashboard")
        }).catch(Err=>{
            Swal.fire({icon:"error",text:Err.response.data.message})
            console.log(Err.response.data)
        })
    }
  return (
    <div className="bg-base h-screen">
      {/* login frontend created */}
        <div className="max-w-3xl py-20  bg-secondary w-full absolute shadow-2xl rounded-3xl h-full max-h-[30rem] top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2">
            <div className=" grid gap-7 grid-cols-2 h-full">
                <div className="flex justify-center items-center border-r-2 border-gray-300">
                    <IoLogoXing className="inline-block text-9xl text-[#4f8269]"/>
                </div>
                <div className="flex px-7  items-center">

                    <form className="w-full" onSubmit={handleSubmit(onSubmit)}>
                    <div className="relative z-0 mb-6 w-full group">
    <input type="email" {...register("email",{ required: true })} name="email" id="floating_email" className="block rounded-lg py-2 px-3 w-full text-sm text-slate-100 bg-transparent border-2  border-gray-300 appearance-none dark:text-white dark:border-gray-600 dark:focus:border-blue-500 focus:outline-none focus:ring-0 focus:border-blue-600 peer" placeholder=" " required />
    <label htmlFor="floating_email" className="peer-focus:font-medium absolute px-2 text-sm text-gray-100 dark:text-gray-400 duration-300 transform -translate-y-6 scale-75 top-3 -z-10 origin-[0] peer-focus:left-0 peer-focus:text-blue-600 peer-focus:dark:text-blue-500 peer-placeholder-shown:scale-100 peer-placeholder-shown:translate-y-0 peer-focus:scale-75 peer-focus:-translate-y-8">Email@address.com</label>
  </div>
                    <div className="relative z-0 mb-8 w-full group">
    <input type="password" {...register("password",{ required: true })} name="password" id="floating_email" className="block rounded-lg py-2 px-3 w-full text-sm text-slate-100 bg-transparent border-2  border-gray-300 appearance-none dark:text-white dark:border-gray-600 dark:focus:border-blue-500 focus:outline-none focus:ring-0 focus:border-blue-600 peer" placeholder=" " required />
    <label htmlFor="floating_email" className="peer-focus:font-medium absolute px-2 text-sm text-gray-100 dark:text-gray-400 duration-300 transform -translate-y-6 scale-75 top-3 -z-10 origin-[0] peer-focus:left-0 peer-focus:text-blue-600 peer-focus:dark:text-blue-500 peer-placeholder-shown:scale-100 peer-placeholder-shown:translate-y-0 peer-focus:scale-75 peer-focus:-translate-y-8">Password</label>
  </div>
  <button className="block bg-[#4f8269] shadow-lg active:border-0 w-full py-2 rounded-lg text-gray-200 ">Connect</button>
                    <div className="justify-between flex mt-4">
                    <a href="#" className="text-sm font-heading font-light text-gray-200 cursor-pointer">forgot password? </a>
                    <div  className="text-sm font-heading font-light text-gray-200 cursor-pointer"><Link href={"/signup"}>Sign up?</Link> </div>

                    </div>
                    </form>
                </div>
            </div>
        </div>

    </div>
  )
}
